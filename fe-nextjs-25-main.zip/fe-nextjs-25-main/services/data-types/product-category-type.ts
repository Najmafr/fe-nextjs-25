export interface ProductCategoryType {
  id?: number;
  name: string;
  description: string;
}
