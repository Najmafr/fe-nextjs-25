export interface ProductVariantType {
    id?: number;
    name: string;
    description: string;
    price: string;
    stock: string;
    product_id: number;
  }
  