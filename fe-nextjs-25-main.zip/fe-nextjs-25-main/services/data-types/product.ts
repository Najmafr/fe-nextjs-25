export interface ProductType {
    id?: number;
    name: string;
    description: string;
    product_category_id: number;
  }
  